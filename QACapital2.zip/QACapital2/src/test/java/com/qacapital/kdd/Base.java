package com.qacapital.kdd;

public class Base {
}
