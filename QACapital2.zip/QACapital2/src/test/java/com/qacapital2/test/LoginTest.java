package com.qacapital2.test;

import com.qacapital2.base.Base;
import com.qacapital2.pages.LoginPage;
import com.qacapital2.util.CustomListner;
import com.qacapital2.util.ReadExcel;
import org.testng.annotations.*;

import java.io.IOException;
@Listeners(CustomListner.class)
public class LoginTest extends Base {

    @BeforeTest
    public void login(){
        initialization();
    }

    @DataProvider(name = "login")
    public Object[][] loginData() throws IOException {
        Object[][] data = ReadExcel.getHardData();
        return data;
    }

    /**
     * @purpose To test login functionality
     * @param username
     * @param password
     */
    @Test(dataProvider = "login")
    public void loginTest(String username, String password) {
        LoginPage loginPage = new LoginPage();
        loginPage.login(username, password);
    }
    @AfterTest
    public void tearDown() throws InterruptedException {
        Thread.sleep(2000);
        driver.quit();
    }

}
