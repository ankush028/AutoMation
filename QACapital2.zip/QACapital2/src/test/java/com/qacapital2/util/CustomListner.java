package com.qacapital2.util;

import org.testng.ITestListener;
import org.testng.ITestResult;

public class CustomListner implements ITestListener {

    public void onTestStart(ITestResult result){
        System.out.println("Starting Test"+result.getName());
    }
    public void onTestSuccess(ITestResult result){
        System.out.println("Passed Test"+result.getName());
    }
}
